import { RoutineItemViewModel } from '../viewmodels/routine.viewmodel';

interface RoutineCardProps {
  routine: RoutineItemViewModel;
}

// Clases estáticas (Tailwind no detecta clases construidas dinámicamente)
const BADGE_STYLES: Record<string, string> = {
  fuerza: 'border-[#4f2de0] text-[#4f2de0]',
  hipertrofia: 'border-[#ec2f8f] text-[#ec2f8f]',
  resistencia: 'border-[#14c9a8] text-[#14c9a8]',
};
const BADGE_FALLBACK = 'border-neutral-400 text-neutral-600';

export function RoutineCard({ routine }: RoutineCardProps) {
  const badgeStyle = BADGE_STYLES[routine.badgeText.trim().toLowerCase()] ?? BADGE_FALLBACK;

  return (
    <div className="flex h-full flex-col gap-3 rounded-xl bg-white p-5 shadow-sm">
      <div>
        <h3 className="text-base font-semibold text-neutral-900">{routine.title}</h3>
        <p className="mt-3 text-sm leading-relaxed text-neutral-600">
          {routine.descriptionText}
        </p>
      </div>

      <span
        className={`mt-auto inline-block w-fit rounded-md border px-2.5 py-0.5 text-sm ${badgeStyle}`}
      >
        {routine.badgeText}
      </span>
    </div>
  );
}